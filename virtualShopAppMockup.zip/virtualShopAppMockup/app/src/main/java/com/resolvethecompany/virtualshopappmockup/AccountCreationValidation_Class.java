package com.resolvethecompany.virtualshopappmockup;

import android.util.Log;
import android.util.Patterns;
import android.widget.EditText;

public class AccountCreationValidation_Class {
    String pinto_validate;

    public Boolean runAll_Checks_Class(EditText emailTextToGRab){
        emailIs_Validated(emailTextToGRab);
        return false;
    }

    //The methods below will be passed into runAll_Checks_Class

    private Boolean emailIs_Validated(EditText grabTextFromHere){
        // extract the entered data from the EditText
        String emailToText = grabTextFromHere.getText().toString();

        // Android offers the inbuilt patterns which the entered
        // data from the EditText field needs to be compared with
        // In this case the the entered data needs to compared with
        // the EMAIL_ADDRESS, which is implemented same below
        if (!emailToText.isEmpty() && Patterns.EMAIL_ADDRESS
                .matcher(emailToText).matches()) {
            Log.d("Email_isValid", "Pass");
            return true;
        } else {
            Log.d("Email_isValid", "Failed");
            return false;
        }
    }

    private Boolean pintIs_Validated(){
        int pin = Integer.parseInt(pinto_validate);

        if(String.valueOf(pin).length() < 4
                || String.valueOf(pin).length() > 4){
            //check fails
            Log.d("Pin_DidPass", "Pass");
            return true;
        }else if(String.valueOf(pin).length() == 4){
            //check passes
            Log.d("Pin_DidPass", "Failed");
            return false;
        }
        return null;
    }

    private Boolean passwordIs_Validated(EditText mainPassword,
                                      EditText confirmpassword){
        if(mainPassword == confirmpassword){
            //pass
            Log.d("password_isValidated", "Passed");
            return true;
        }else{
            Log.d("password_isValidated", "Failed");
            return false;
        }
    }
}
